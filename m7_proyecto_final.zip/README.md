# M6_SitioMedicoDjango
Examen módulo 6 Django


El servidor web para InterSalud es Nginx:

  Nginx es  un servidor web de codigo abierto y altamente configurable, provee una altapacidad en solicitudes concurrentes y de alto flujo, 
como lo requiere el sistema de InterSalud, la cual es una  plataforma que pretende atender peticiones de todos los centros de salud del país.

 Esta tecnologia que provee un servicio de hosting completo y actua bajo la licencia BSD. A diferencia de  su compentencia a nivel nacional mas cercana  (Apache) 
en cuanto a l  provisicionamiento  de servicios web , Nginx tiene  una capacidad de respuesta de peticiones de alrededor 4 veces mas rapida . Además para establecer 
una arquitectura de software mas completa esta herramienta permite  la configuracion de balanceadores de carga HTTP, los cuales manejan las peticiones de forma
balanceada entre diversos servidores, procurando que no colpasen y mantenteniendo el respaldo de los archivos en diferentes locaciones. Otra de sus cualidades es la 

  Finalmente por las razones mencionadas, hemos seleccionado a Nginx como el servidor HTTP ideal para un proyecto de la embergadura de InterSalud.
